import { useState, useEffect } from "react";
import { Navigate, useParams } from "react-router-dom";
import NavBar from "../components/navbar.jsx";
import Drawer from "../components/drawer.jsx";

// Pour les pages
import ListeCat from "../components/listecat.jsx";
import AjouterCat from "../components/ajoutercat.jsx";
import AjouterProduit from "../components/ajouterproduit.jsx";
import ListeProduit from "../components/listeproduit.jsx";
import AjouterFacture from "../components/ajouterfacture.jsx";
import ListeFacture from "../components/listefacture.jsx";
import FactureProforma from "../components/factureProforma.jsx";
import toast from "react-hot-toast";

function Accueil({ tokens, setTokens }) {
  const [isCollapsed, setIsCollapsed] = useState(false); // État pour gérer l'ouverture/fermeture

  const { id } = useParams(); // Récupérer l'ID depuis l'URL
  
  // Redirection si l'ID ne correspond pas au token
  if (id !== tokens.token) {
    return <Navigate to="/" replace />;
  }

  const [liste, setListe] = useState([]); // Catégories
  const [listproduit, setListeproduit] = useState([]); // Produits
  const [page, setPage] = useState(0); // Gestion de la page active
  const [isDrawerOpen, setIsDrawerOpen] = useState(true); // Gestion de la visibilité du drawer

  // Fonction pour charger les données depuis l'API
  const fetchData = async (url, setData, errorMessage) => {
    try {
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setData(data.data); // Mise à jour de l'état
      } else {
      }
    } catch (error) {
      toast.error("Erreur serveur.");
    }
  };

  // Charger les catégories
  useEffect(() => {
    fetchData(
      "https://api.trendybox-dz.com/CategorieAll",
      setListe,
      "Erreur lors de la récupération des catégories."
    );
  }, []);

  // Charger les produits
  useEffect(() => {
    fetchData(
      "https://api.trendybox-dz.com/ProduitAll",
      setListeproduit,
      "Erreur lors de la récupération des produits."
    );
  }, []);

  return (
    <div className="w-full h-[100vh]">
      {/* Barre de navigation */}
      <NavBar />

      {/* Contenu principal */}
      <div className="w-full flex">
        {/* Drawer (barre latérale) */}
        {isDrawerOpen && <Drawer setPage={setPage}    isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} closeDrawer={() => setIsDrawerOpen(false)} />}

        {/* Contenu principal */}
        <div
          style={{
            width: ! isCollapsed ? "calc(100vw - 18vw)" : "100vw",
            height: "calc(100vh - 80px)",
            overflow: "auto",
          }}
        >
          {/* Bouton pour rouvrir le drawer */}
          {!isDrawerOpen && (
            <button
              onClick={() => setIsDrawerOpen(true)}
              style={{
                position: "fixed",
                top: "20px",
                left: "20px",
                padding: "10px",
                backgroundColor: "#004d00",
                color: "#fff",
                borderRadius: "5px",
                border: "none",
                cursor: "pointer",
              }}
            >
              Ouvrir le menu
            </button>
          )}

          {/* Rendu conditionnel des composants */}
          {page === 0 && <ListeCat liste={liste} setListe={setListe} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />}
          {page === 1 && <AjouterCat fetchData={fetchData}  isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />} 
          {page === 2 && <ListeProduit produits={listproduit} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed}  />}
          {page === 3 && <AjouterProduit liste={liste} fetchData={fetchData}  isCollapsed={isCollapsed}  setIsCollapsed={setIsCollapsed}  />}
          {page === 4 && <AjouterFacture listproduit={listproduit}  liste={liste} isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />}
          {page === 5 && <ListeFacture isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />}
          {page === 6 && <FactureProforma isCollapsed={isCollapsed} setIsCollapsed={setIsCollapsed} />}

        </div>
      </div>
    </div>
  );
}

export default Accueil;
