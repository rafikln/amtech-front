import React, { useState, useEffect } from "react";
import { PDFDownloadLink } from "@react-pdf/renderer";
import toast from "react-hot-toast";
import FacturePDF from "./pdf.jsx";
import UpdateFacture from "./updatefacture.jsx";
import ConfirmedeleteFact from "./confirmedeletefact.jsx";
import ModelShowFacture from "./ModelShowFacture.jsx";

import pdf from "../icon/pdf.svg";
import Delete from "../icon/delete.svg";
import Show from "../icon/show.svg";

const ListeFacture = () => {
  const [factures, setFactures] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredFactures, setFilteredFactures] = useState([]);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [selectedFacture, setSelectedFacture] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteFactureId, setDeleteFactureId] = useState(null);
  const [dateStart, setDateStart] = useState("");
  const [dateEnd, setDateEnd] = useState("");
  const [isShowModalOpen, setIsShowModalOpen] = useState(false);

  useEffect(() => {
    const fetchFactures = async () => {
      try {
        const response = await fetch("https://il-developer.com/api/factures");
        if (!response.ok) throw new Error("Erreur lors de la récupération");
        const result = await response.json();
        if (result.success) {
          // Ajout d'un statut par défaut si non présent
          const updatedFactures = result.data.map(facture => ({
            ...facture,
            status: facture.status || "jaune" // Par défaut en cours
          }));
          setFactures(updatedFactures);
          setFilteredFactures(updatedFactures);
        }
      } catch (error) {
        toast.error("Erreur lors du chargement des factures !");
        console.error(error);
      }
    };
    fetchFactures();
  }, []);

  useEffect(() => {
    let filtered = factures.filter(
      (facture) =>
        facture.nom_client.toLowerCase().includes(searchTerm.toLowerCase()) ||
        facture.id.toString().includes(searchTerm)
    );

    if (dateStart && dateEnd) {
      const start = new Date(dateStart);
      const end = new Date(dateEnd);
      end.setHours(23, 59, 59, 999);
      filtered = filtered.filter((facture) => {
        const factureDate = new Date(facture.date_creation);
        return factureDate >= start && factureDate <= end;
      });
    }
    setFilteredFactures(filtered);
  }, [searchTerm, dateStart, dateEnd, factures]);

  const handleOpenDeleteModal = (factureId) => {
    setDeleteFactureId(factureId);
    setIsDeleteModalOpen(true);
  };

  const handleConfirmDelete = async () => {
    if (!deleteFactureId) return;
    try {
      const response = await fetch(`https://il-developer.com/api/factures/${deleteFactureId}`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" }
      });
      if (!response.ok) throw new Error("Erreur lors de la suppression");
      setFactures(prev => prev.filter(facture => facture.id !== deleteFactureId));
      setIsDeleteModalOpen(false);
      toast.success("Facture supprimée avec succès !");
    } catch (err) {
      toast.error("Échec de la suppression !");
      console.error(err);
    }
  };

  const handleCancelDelete = () => {
    setDeleteFactureId(null);
    setIsDeleteModalOpen(false);
  };

  const handleOpenShowModal = (facture) => {
    setSelectedFacture(facture);
    setIsShowModalOpen(true);
  };

  const handleCloseShowModal = () => {
    setSelectedFacture(null);
    setIsShowModalOpen(false);
  };

  // Fonction pour mettre à jour le statut
  const updateFactureStatus = async (factureId, newStatus) => {
    try {
      const response = await fetch(`https://il-developer.com/api/factures/${factureId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (!response.ok) throw new Error("Erreur lors de la mise à jour");
      const updatedFacture = await response.json();
      
      setFactures(prev => prev.map(facture => 
        facture.id === factureId ? { ...facture, status: newStatus } : facture
      ));
      setSelectedFacture(prev => ({ ...prev, status: newStatus }));
      toast.success("Statut mis à jour avec succès !");
    } catch (err) {
      toast.error("Erreur lors de la mise à jour du statut !");
      console.error(err);
    }
  };

  const getRowColor = (status) => {
    switch (status) {
      case "rouge": return "bg-red-100";
      case "jaune": return "bg-yellow-200";
      case "vert": return "bg-green-100";
      default: return "bg-white";
    }
  };

  const formatDate = (isoDate) => {
    return new Date(isoDate).toISOString().split("T")[0];
  };

  return (
    <div>
      {/* En-tête existant */}
      <div className="w-full h-[90px] flex justify-between items-center p-[30px]">
        <div className="breadcrumbs text-sm">
          <ul>
            <li className="text-[gray]"><a>Accueil</a></li>
            <li className="text-[blue]"><a>Liste Facture</a></li>
          </ul>
        </div>
        <input
          type="text"
          className="px-4 py-2 rounded-md shadow-md border focus:outline-none"
          placeholder="Rechercher par nom"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Filtres de date existants */}
      <div className="flex items-center justify-center gap-2 space-x-4 mt-4">
        <div className="flex items-center gap-2">
          <label className="text-gray-700">De :</label>
          <input type="date" className="p-2 border rounded-md" value={dateStart} onChange={(e) => setDateStart(e.target.value)} />
        </div>
        <div className="flex items-center gap-2">
          <label className="text-gray-700">À :</label>
          <input type="date" className="p-2 border rounded-md" value={dateEnd} onChange={(e) => setDateEnd(e.target.value)} />
        </div>
      </div>

      {/* Tableaux avec couleurs */}
      <div className="overflow-x-auto mt-6">
        <div className="w-full pl-[30px] pr-[80px]">
          <table className="table-auto w-full border-collapse border border-gray-300">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left">#Num</th>
                <th className="px-4 py-2 text-left">Nom du client</th>
                <th className="px-4 py-2 text-left">Date</th>
                <th className="px-4 py-2 text-left">Prix Total</th>
                <th className="px-4 py-2 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredFactures.length > 0 ? (
                filteredFactures.map((facture) => (
                  <tr key={facture.id} className={`${getRowColor(facture.status)} hover:opacity-90`}>
                    <td className="px-4 py-2">{facture.id}</td>
                    <td className="px-4 py-2">{facture.nom_client}</td>
                    <td className="px-4 py-2">{formatDate(facture.date_creation)}</td>
                    <td className="px-4 py-2">{facture.prix_total} DA</td>
                    <td className="px-4 py-2 flex space-x-2">
                      <button
                        onClick={() => handleOpenShowModal(facture)}
                        className="w-8 h-8 flex justify-center items-center bg-blue-600 text-white rounded-md hover:bg-blue-500"
                      >
                        <img src={Show} alt="show" className="w-5 h-5" />
                      </button>
                      <PDFDownloadLink document={<FacturePDF facture={facture} />} fileName={`Facture_${facture.id}.pdf`}>
                        <button className="w-8 h-8 flex justify-center items-center bg-gray-600 text-white rounded-md hover:bg-gray-500">
                          <img src={pdf} alt="pdf" className="w-5 h-5" />
                        </button>
                      </PDFDownloadLink>
                      <button 
                        onClick={() => handleOpenDeleteModal(facture.id)} 
                        className="w-8 h-8 flex justify-center items-center bg-red-600 text-white rounded-md hover:bg-red-500"
                      >
                        <img src={Delete} alt="delete" className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="text-center text-gray-500 px-4 py-2">Aucune facture trouvée</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modales existantes */}
      <ConfirmedeleteFact 
        isOpen={isDeleteModalOpen} 
        onConfirm={handleConfirmDelete} 
        onCancel={handleCancelDelete} 
      />
      <ModelShowFacture
        isModalOpen={isShowModalOpen}
        selectedFacture={selectedFacture}
        handleCloseModal={handleCloseShowModal}
        updateFactureStatus={updateFactureStatus} // Passage de la fonction de mise à jour
      />
    </div>
  );
};

export default ListeFacture;