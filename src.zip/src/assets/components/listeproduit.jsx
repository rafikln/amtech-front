import React, { useState, useEffect } from "react";
import ConfirmedeleteProduit from "./confirmedeleteproduit";
import ModelShowProduit from "../components/modelshowproduit";
import ModelUpdateProduit from "../components/modelupdateproduit";
import show from "../icon/show.svg";
import update from "../icon/update.svg";
import delet from "../icon/delete.svg";
import toast from "react-hot-toast";
import jsPDF from "jspdf";
import "jspdf-autotable";
import JsBarcode from "jsbarcode";
import * as XLSX from "xlsx";

const ListeProduit = () => {
  const [produits, setProduits] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [loading, setLoading] = useState(true);

  const API_URL = "https://il-developer.com";

  const generateBarcode = (code) => {
    try {
      const canvas = document.createElement("canvas");
      JsBarcode(canvas, code, {
        format: "CODE128",
        width: 2,
        height: 60,
        displayValue: true,
        fontSize: 12,
        margin: 0,
        textMargin: 2,
        background: "#FFFFFF",
        lineColor: "#000000",
      });
      return canvas.toDataURL("image/png");
    } catch (error) {
      console.error("Erreur lors de la génération du code-barres:", error);
      throw error;
    }
  };

  const generateProductTicket = (produit) => {
    try {
      const doc = new jsPDF({
        orientation: "landscape",
        unit: "mm",
        format: [45, 35],
      });
      let code = produit.reference || produit.id.toString();
      const barcodeDataUrl = generateBarcode(code);
      doc.addImage(barcodeDataUrl, "PNG", 5, 5, 35, 15);
      doc.save(`ticket_${produit.reference || produit.id}.pdf`);
    } catch (error) {
      console.error("Erreur lors de la génération du ticket:", error);
      toast.error("Erreur lors de la génération du ticket.");
    }
  };

  const fetchProduits = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/api/produits`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const result = await response.json();
      if (!result.success) throw new Error(result.message || "Erreur lors de la récupération des produits");
      setProduits(result.data || []);
    } catch (error) {
      console.error("Erreur fetchProduits:", error);
      toast.error(error.message || "Erreur serveur");
      setProduits([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProduits();
  }, []);

  // Exporter toutes les informations des produits en Excel
  const exportToExcel = () => {
    // Préparer les données en incluant toutes les propriétés des produits
    const exportData = produits.map((produit) => {
      const flatProduit = { ...produit }; // Copie de l'objet produit

      // Gérer le champ image si c'est un tableau ou une chaîne
      if (flatProduit.image) {
        if (Array.isArray(flatProduit.image)) {
          flatProduit.image = flatProduit.image.map((img) => img.path || img).join(", ");
        } else if (typeof flatProduit.image === "string") {
          try {
            const parsed = JSON.parse(flatProduit.image);
            flatProduit.image = Array.isArray(parsed)
              ? parsed.map((img) => img.path || img).join(", ")
              : parsed.path || parsed;
          } catch {
            flatProduit.image = flatProduit.image; // Garder tel quel si non parsable
          }
        }
      }

      // Ajouter l'unité monétaire au prix
      if (flatProduit.prix_vente) {
        flatProduit.prix_vente = `${flatProduit.prix_vente} DA`;
      }

      return flatProduit;
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Produits");

    // Personnaliser les en-têtes (optionnel)
    worksheet["!cols"] = Object.keys(exportData[0] || {}).map(() => ({ wch: 20 })); // Ajuster la largeur des colonnes

    XLSX.writeFile(workbook, "liste_produits_complet.xlsx");
    toast.success("Produits exportés avec succès en Excel !");
  };

  const handleImport = () => {
    toast.info("Fonctionnalité d'importation à implémenter.");
  };

  const produitsFiltres = produits.filter(
    (produit) =>
      produit.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (produit.reference && produit.reference.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleShowModal = (produit) => {
    setSelectedProduct(produit);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  const handleShowUpdateModal = (produit) => {
    setSelectedProduct(produit);
    setIsUpdateModalOpen(true);
  };

  const handleCloseUpdateModal = () => {
    setIsUpdateModalOpen(false);
    setSelectedProduct(null);
  };

  const handleOpenDeleteModal = (id) => {
    setSelectedProductId(id);
    setIsConfirmModalOpen(true);
  };

  const handleCancelDelete = () => {
    setIsConfirmModalOpen(false);
    setSelectedProductId(null);
  };

  const handleDeleteProduct = async () => {
    try {
      const response = await fetch(`${API_URL}/api/produits/${selectedProductId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Erreur lors de la suppression");
      setProduits((prev) => prev.filter((p) => p.id !== selectedProductId));
      setIsConfirmModalOpen(false);
      toast.success(result.message || "Produit supprimé avec succès");
    } catch (error) {
      console.error("Erreur handleDeleteProduct:", error);
      toast.error(error.message || "Erreur lors de la suppression");
    }
  };

  const getProductImage = (produit) => {
    try {
      if (!produit.image) return null;
      if (Array.isArray(produit.image)) {
        const firstImage = produit.image[0];
        return firstImage?.path ? `${API_URL}/${firstImage.path}` : null;
      }
      if (typeof produit.image === "string") {
        try {
          const parsed = JSON.parse(produit.image);
          if (Array.isArray(parsed)) {
            const firstImg = parsed[0];
            return firstImg?.path ? `${API_URL}/${firstImg.path}` : null;
          }
          return parsed?.path ? `${API_URL}/${parsed.path}` : null;
        } catch {
          return `${API_URL}/${produit.image}`;
        }
      }
      return null;
    } catch (error) {
      console.error("Erreur traitement image:", error);
      return null;
    }
  };

  if (loading) {
    return (
      <div className="w-full h-screen flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <>
      <div className="w-full h-[90px] flex justify-between items-center p-[30px]">
        <div className="breadcrumbs text-sm">
          <ul>
            <li className="text-[gray]"><a>Accueil</a></li>
            <li className="text-[blue]"><a>Liste Produit</a></li>
          </ul>
        </div>
        <div className="flex gap-4 items-center">
        
          <button
            onClick={handleImport}
            className="w-[120px] h-[40px] flex items-center justify-center gap-2 rounded-md bg-[#2196F3] text-white hover:bg-[#1976D2] transition"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              viewBox="0 0 16 16"
            >
              <path d="M11.5 4a.5.5 0 0 1 .5.5V12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4.5a.5.5 0 0 1 1 0V12a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1V4.5a.5.5 0 0 1 .5-.5z"/>
              <path d="M8 1a.5.5 0 0 1 .5.5v7.793l2.146-2.147a.5.5 0 0 1 .708.708l-3 3a.5.5 0 0 1-.708 0l-3-3a.5.5 0 1 1 .708-.708L7.5 9.293V1.5A.5.5 0 0 1 8 1z"/>
            </svg>
            Importer
          </button>
          <button
            onClick={exportToExcel}
            className="w-[120px] h-[40px] flex items-center justify-center gap-2 rounded-md bg-[#4CAF50] text-white hover:bg-[#388E3C] transition"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              fill="currentColor"
              viewBox="0 0 16 16"
            >
              <path d="M11.5 12a.5.5 0 0 0 .5-.5V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7.5a.5.5 0 0 0 1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v7.5a.5.5 0 0 0 .5.5z"/>
              <path d="M8 15a.5.5 0 0 0 .5-.5V6.707l2.146 2.147a.5.5 0 0 0 .708-.708l-3-3a.5.5 0 0 0-.708 0l-3 3a.5.5 0 1 0 .708.708L7.5 6.707V14.5a.5.5 0 0 0 .5.5z"/>
            </svg>
            Exporter
          </button>
        </div>
        <div className="w-[190px] h-[50px]">
            <input
              type="text"
              className="grow rounded-md w-full h-full px-2 border border-gray-300"
              placeholder="Search"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
      </div>

      <div className="pl-[30px] pr-[80px]">
        {produits.length === 0 ? (
          <div className="text-center py-10">
            <p>Aucun produit disponible</p>
          </div>
        ) : (
          <div className="relative overflow-x-auto shadow-md sm:rounded-lg">
            <table className="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" className="px-16 py-3"><span>Image</span></th>
                  <th scope="col" className="px-6 py-3">Nom de produit</th>
                  <th scope="col" className="px-6 py-3">Qte</th>
                  <th scope="col" className="px-6 py-3">Prix</th>
                  <th scope="col" className="px-6 py-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {produitsFiltres.map((produit) => (
                  <tr
                    key={produit.id}
                    className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"
                  >
                    <td className="p-4">
                      <div className="w-[160px] h-[160px] flex flex-col justify-center items-center">
                        <img
                          src={getProductImage(produit)}
                          className="w-[90%]"
                          style={{
                            margin: "0 auto",
                            display: "block",
                            borderRadius: "5px",
                            userSelect: "none",
                            objectFit: "cover",
                          }}
                          alt={produit.nom}
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = placeholderImage; // Placeholder à définir
                          }}
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4 w-[30%] font-semibold text-gray-900 dark:text-white">
                      {produit.nom}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center">
                        <input
                          type="number"
                          disabled
                          value={produit.quantite}
                          className="bg-gray-50 w-[65px] text-center border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-2 py-1 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        />
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold w-[13%] text-gray-900 dark:text-white">
                      {produit.prix_vente} DA
                    </td>
                    <td className="h-[170px] flex gap-2 items-center">
                      <div
                        className="w-[33px] h-[30px] flex justify-center p-1 items-center rounded-md bg-[#827474] cursor-pointer"
                        onClick={() => handleShowModal(produit)}
                      >
                        <img src={show} alt="show" />
                      </div>
                      <div
                        className="w-[33px] h-[30px] flex justify-center p-1 items-center rounded-md bg-[#3e47f5] cursor-pointer"
                        onClick={() => handleShowUpdateModal(produit)}
                      >
                        <img src={update} alt="update" />
                      </div>
                      <div
                        className="w-[33px] h-[30px] flex justify-center p-1 items-center rounded-md bg-[#d14f4f] cursor-pointer"
                        onClick={() => handleOpenDeleteModal(produit.id)}
                      >
                        <img src={delet} alt="delete" />
                      </div>
                      <div
                        className="w-[33px] h-[30px] flex justify-center p-1 items-center rounded-md bg-[#4CAF50] cursor-pointer"
                        onClick={() => generateProductTicket(produit)}
                        title="Générer ticket PDF"
                      >
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="16"
                          height="16"
                          fill="white"
                          viewBox="0 0 16 16"
                        >
                          <path d="M5 1a2 2 0 0 0-2 2v1h10V3a2 2 0 0 0-2-2H5zm6 8H5a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1z"/>
                          <path d="M0 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-1v-2a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2H2a2 2 0 0 1-2-2V7zm2.5 1a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                        </svg>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ConfirmedeleteProduit
        isConfirmModalOpen={isConfirmModalOpen}
        handleDeleteCategory={handleDeleteProduct}
        handleCancelDelete={handleCancelDelete}
      />
      <ModelShowProduit
        isModalOpen={isModalOpen}
        selectedProduct={selectedProduct}
        handleCloseModal={handleCloseModal}
      />
      <ModelUpdateProduit
        fetchProduits={fetchProduits}
        isUpdateModalOpen={isUpdateModalOpen}
        selectedProduct={selectedProduct}
        handleCloseUpdateModal={handleCloseUpdateModal}
      />
    </>
  );
};

export default ListeProduit;