import React, { useState, useEffect, useRef } from "react";
import toast from "react-hot-toast";

const AjouterFacture = () => {
  const [achat, setAchat] = useState({
    client: {
      nomComplet: "",
      telephone: "",
      email: "",
      wilaya: "",
      recommandation: "",
    },
    produits: [],
  });
  const [totalPrix, setTotalPrix] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [categories, setCategories] = useState([]);
  const [produitsDisponibles, setProduitsDisponibles] = useState([]);
  const [barcode, setBarcode] = useState("");
  const barcodeInputRef = useRef(null);
  const searchInputRef = useRef(null);
  const [isClientModalOpen, setIsClientModalOpen] = useState(false);
  const [isWarrantyModalOpen, setIsWarrantyModalOpen] = useState(false);
  const [isSaleModalOpen, setIsSaleModalOpen] = useState(true);
  const [selectedProductId, setSelectedProductId] = useState(null);
  const [warrantyData, setWarrantyData] = useState({
    code_garantie: "",
    duree_garantie: "",
  });
  const [saleData, setSaleData] = useState({
    saleType: "comptoir", // "comptoir" ou "livraison"
    saleMode: "direct",   // "direct" ou "versement"
    deliveryProvider: "yalidine",
    deliveryPrice: "",
    comment: "",
    paymentMethods: [],   // [{ method: "cash", installments: [{ amount, date }] }]
  });

  const API_URL = "https://il-developer.com";

  const wilayas = [
    "Adrar", "Chlef", "Laghouat", "Oum El Bouaghi", "Batna", "Béjaïa", "Biskra", "Béchar", "Blida", "Bouira",
    "Tamanrasset", "Tébessa", "Tlemcen", "Tiaret", "Tizi Ouzou", "Alger", "Djelfa", "Jijel", "Sétif", "Saïda",
    "Skikda", "Sidi Bel Abbès", "Annaba", "Guelma", "Constantine", "Médéa", "Mostaganem", "M'Sila", "Mascara",
    "Ouargla", "Oran", "El Bayadh", "Illizi", "Bordj Bou Arréridj", "Boumerdès", "El Tarf", "Tindouf", "Tissemsilt",
    "El Oued", "Khenchela", "Souk Ahras", "Tipaza", "Mila", "Aïn Defla", "Naâma", "Aïn Témouchent", "Ghardaïa",
    "Relizane", "Timimoun", "Bordj Badji Mokhtar", "Ouled Djellal", "Béni Abbès", "In Salah", "In Guezzam",
    "Touggourt", "Djanet", "El M'Ghair", "El Meniaa"
  ];

  const recommandations = [
    "Réseaux sociaux",
    "Ami/Famille",
    "Publicité",
    "Site web",
    "Autre"
  ];

  const paymentOptions = [
    { value: "cash", label: "Cash", icon: <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg> },
    { value: "ccp", label: "CCP", icon: <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" /></svg> },
    { value: "yalidine", label: "Yalidine", icon: <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> },
  ];

  const truncateText = (text, maxLength) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  useEffect(() => {
    let barcodeBuffer = '';
    let lastKeyTime = 0;
    let timeoutId = null;

    const handleKeyDown = (e) => {
      const currentTime = new Date().getTime();
      const timeDiff = currentTime - lastKeyTime;
      const activeElement = document.activeElement;

      if (!activeElement || activeElement === searchInputRef.current || activeElement === barcodeInputRef.current) {
        const keyMap = {
          '&': '1', 'é': '2', '"': '3', "'": '4', '(': '5', '§': '6', 'è': '7', '!': '8', 'ç': '9', 'à': '0',
        };

        if (/^[0-9]$/.test(e.key)) {
          barcodeBuffer += e.key;
          e.preventDefault();
        } else if (keyMap[e.key]) {
          barcodeBuffer += keyMap[e.key];
          e.preventDefault();
        } else if (e.key === 'Enter' && barcodeBuffer.length > 0) {
          processBarcode(barcodeBuffer);
          barcodeBuffer = '';
          e.preventDefault();
        }

        lastKeyTime = currentTime;

        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          if (barcodeBuffer.length > 0) {
            processBarcode(barcodeBuffer);
            barcodeBuffer = '';
          }
        }, 300);
      }
    };

    const processBarcode = (code) => {
      const numericCode = code.replace(/[^0-9]/g, '');
      if (numericCode.length === 0) {
        toast.error("Code-barres invalide (aucun chiffre détecté).");
        return;
      }

      const produit = produitsDisponibles.find((p) => p.id.toString() === numericCode);
      if (produit && produit.quantite > 0) {
        handleAddToCart(produit);
        toast.success(`${produit.nom} ajouté au panier !`);
        setSearchTerm('');
      } else {
        toast.error("Produit non trouvé ou en rupture de stock.");
      }
      setBarcode('');
      maintainBarcodeFocus();
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      clearTimeout(timeoutId);
    };
  }, [produitsDisponibles]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch(`${API_URL}/api/categories`);
        if (!response.ok) throw new Error("Erreur lors de la récupération des catégories.");
        const result = await response.json();
        if (!result.success) throw new Error(result.message || "Erreur serveur.");
        setCategories(result.data || []);
      } catch (error) {
        toast.error(error.message || "Erreur serveur (catégories).");
      }
    };

    const fetchProduits = async () => {
      try {
        const response = await fetch(`${API_URL}/api/produits`);
        if (!response.ok) throw new Error("Erreur lors de la récupération des produits.");
        const result = await response.json();
        if (!result.success) throw new Error(result.message || "Erreur serveur.");
        setProduitsDisponibles(result.data || []);
      } catch (error) {
        toast.error(error.message || "Erreur serveur (produits).");
      }
    };

    fetchCategories();
    fetchProduits();
  }, []);

  useEffect(() => {
    const total = achat.produits.reduce((sum, produit) => sum + produit.prix * produit.quantite, 0);
    setTotalPrix(total);
  }, [achat.produits]);

  const maintainBarcodeFocus = () => {
    setTimeout(() => {
      if (barcodeInputRef.current) {
        barcodeInputRef.current.focus();
      }
    }, 50);
  };

  const filteredProduits = produitsDisponibles.filter((prod) => {
    const matchesSearch = prod.nom.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || prod.categorie_id === Number(selectedCategory);
    const inStock = prod.quantite > 0;
    return matchesSearch && matchesCategory && inStock;
  });

  const handleAddToCart = (produit) => {
    setAchat((prevAchat) => {
      const produitExistant = prevAchat.produits.find((p) => p.produit_id === produit.id);
      if (produitExistant) {
        return {
          ...prevAchat,
          produits: prevAchat.produits.map((p) =>
            p.produit_id === produit.id
              ? { ...p, quantite: Math.min(p.quantite + 1, produit.quantite) }
              : p
          ),
        };
      }
      return {
        ...prevAchat,
        produits: [
          ...prevAchat.produits,
          {
            produit_id: produit.id,
            quantite: 1,
            prix: produit.prix_vente,
            code_garantie: "",
            duree_garantie: "",
          },
        ],
      };
    });
    maintainBarcodeFocus();
  };

  const handleRemoveProduit = (produit_id) => {
    setAchat((prevAchat) => ({
      ...prevAchat,
      produits: prevAchat.produits.filter((p) => p.produit_id !== produit_id),
    }));
    maintainBarcodeFocus();
  };

  const handlePriceChange = (produit_id, newPrice) => {
    const normalizedPrice = newPrice.replace(',', '.');
    setAchat((prevAchat) => ({
      ...prevAchat,
      produits: prevAchat.produits.map((p) =>
        p.produit_id === produit_id
          ? { ...p, prix: normalizedPrice === '' ? 0 : parseFloat(normalizedPrice) || p.prix }
          : p
      ),
    }));
  };

  const handleOpenClientModal = () => setIsClientModalOpen(true);
  const handleCloseClientModal = () => setIsClientModalOpen(false);

  const handleClientChange = (e) => {
    const { name, value } = e.target;
    setAchat((prevAchat) => ({
      ...prevAchat,
      client: { ...prevAchat.client, [name]: value },
    }));
  };

  const handleSaveClient = () => {
    handleCloseClientModal();
    toast.success("Informations du client enregistrées !");
  };

  const handleOpenWarrantyModal = (produit_id) => {
    setSelectedProductId(produit_id);
    const product = achat.produits.find((p) => p.produit_id === produit_id);
    setWarrantyData({
      code_garantie: product.code_garantie || "",
      duree_garantie: product.duree_garantie || "",
    });
    setIsWarrantyModalOpen(true);
  };

  const handleCloseWarrantyModal = () => {
    setIsWarrantyModalOpen(false);
    setSelectedProductId(null);
  };

  const handleWarrantyChange = (e) => {
    const { name, value, type, checked } = e.target;
    setWarrantyData((prevData) => ({
      ...prevData,
      [name]: type === "checkbox" ? (checked ? value : "") : value,
    }));
  };

  const handleSaveWarranty = () => {
    setAchat((prevAchat) => ({
      ...prevAchat,
      produits: prevAchat.produits.map((p) =>
        p.produit_id === selectedProductId
          ? { ...p, code_garantie: warrantyData.code_garantie, duree_garantie: warrantyData.duree_garantie }
          : p
      ),
    }));
    handleCloseWarrantyModal();
    toast.success("Garantie enregistrée !");
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (achat.produits.length === 0) {
      toast.error("Veuillez ajouter au moins un produit.");
      return;
    }

    setIsSaleModalOpen(true);
  };

  const handleCloseSaleModal = () => {
    setIsSaleModalOpen(false);
  };

  const handleSaleChange = (e) => {
    const { name, value } = e.target;
    setSaleData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handlePaymentChange = (method, checked) => {
    setSaleData((prevData) => {
      if (checked) {
        if (!prevData.paymentMethods.find((pm) => pm.method === method)) {
          return {
            ...prevData,
            paymentMethods: [...prevData.paymentMethods, { method, installments: [{ amount: "", date: "" }] }],
          };
        }
      } else {
        return {
          ...prevData,
          paymentMethods: prevData.paymentMethods.filter((pm) => pm.method !== method),
        };
      }
      return prevData;
    });
  };

  const handlePaymentInstallmentChange = (method, index, field, value) => {
    setSaleData((prevData) => ({
      ...prevData,
      paymentMethods: prevData.paymentMethods.map((pm) =>
        pm.method === method
          ? {
              ...pm,
              installments: pm.installments.map((inst, i) =>
                i === index ? { ...inst, [field]: value } : inst
              ),
            }
          : pm
      ),
    }));
  };

  const addInstallment = (method) => {
    setSaleData((prevData) => ({
      ...prevData,
      paymentMethods: prevData.paymentMethods.map((pm) =>
        pm.method === method
          ? { ...pm, installments: [...pm.installments, { amount: "", date: "" }] }
          : pm
      ),
    }));
  };

  const removeInstallment = (method, index) => {
    setSaleData((prevData) => ({
      ...prevData,
      paymentMethods: prevData.paymentMethods.map((pm) =>
        pm.method === method
          ? {
              ...pm,
              installments: pm.installments.filter((_, i) => i !== index),
            }
          : pm
      ),
    }));
  };

  const handleConfirmSale = async () => {
    const totalWithDelivery =
      totalPrix + (saleData.saleType === "livraison" ? parseFloat(saleData.deliveryPrice) || 0 : 0);
    const totalPayment = saleData.paymentMethods.reduce((sum, pm) => {
      return (
        sum +
        pm.installments.reduce((instSum, inst) => instSum + (parseFloat(inst.amount) || 0), 0)
      );
    }, 0);

    if (saleData.paymentMethods.length === 0) {
      toast.error("Veuillez sélectionner au moins un mode de paiement.");
      return;
    }

    if (saleData.saleMode === "direct" && totalPayment !== totalWithDelivery) {
      toast.error(
        `La somme des paiements (${totalPayment} DA) doit correspondre au total (${totalWithDelivery} DA) pour une vente directe.`
      );
      return;
    }

    if (saleData.saleMode === "versement") {
      const hasEmptyFields = saleData.paymentMethods.some((pm) =>
        pm.installments.some((inst) => !inst.amount || !inst.date)
      );
      if (hasEmptyFields) {
        toast.error("Veuillez remplir tous les montants et dates pour les versements.");
        return;
      }
    }

    const payload = {
      client: {
        nom: achat.client.nomComplet || "anonyme",
        email: achat.client.email || "",
        telephone: achat.client.telephone || "",
        wilaya: achat.client.wilaya || "",
        recommendation: achat.client.recommandation || "",
      },
      produits: achat.produits.map((produit) => ({
        produit_id: produit.produit_id,
        quantite: produit.quantite,
        prix: produit.prix,
        code_garantie: produit.code_garantie || "",
        duree_garantie: produit.duree_garantie || "",
      })),
      saleType: saleData.saleType,
      saleMode: saleData.saleMode,
      deliveryProvider: saleData.saleType === "livraison" ? saleData.deliveryProvider : "",
      deliveryPrice: saleData.saleType === "livraison" ? parseFloat(saleData.deliveryPrice) || 0 : 0,
      comment: saleData.comment,
      paymentMethods: saleData.paymentMethods,
    };

    try {
      const response = await fetch(`${API_URL}/api/factures/with-client`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `Erreur HTTP ${response.status}`);
      }

      const result = await response.json();
      if (!result.success) {
        throw new Error(result.message || "Erreur serveur.");
      }

      toast.success(result.message || "Facture et client créés avec succès !");

      setAchat({
        client: { nomComplet: "", telephone: "", email: "", wilaya: "", recommandation: "" },
        produits: [],
      });
      setSaleData({
        saleType: "comptoir",
        saleMode: "direct",
        deliveryProvider: "yalidine",
        deliveryPrice: "",
        comment: "",
        paymentMethods: [],
      });

      const refreshResponse = await fetch(`${API_URL}/api/produits`, {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (!refreshResponse.ok) {
        throw new Error("Erreur lors de la mise à jour des produits.");
      }
      const refreshResult = await refreshResponse.json();
      setProduitsDisponibles(refreshResult.data || []);

      maintainBarcodeFocus();
      handleCloseSaleModal();
    } catch (error) {
      toast.error(error.message || "Erreur serveur lors de la création de la facture.");
    }
  };

  const getProductImage = (produit) => {
    try {
      if (produit.image && Array.isArray(produit.image) && produit.image[0]?.path) {
        return `${API_URL}/${produit.image[0].path}`;
      }
      return `${API_URL}/uploads/default.jpg`;
    } catch {
      return `${API_URL}/uploads/default.jpg`;
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSearchKeyPress = (e) => {
    if (e.key === 'Enter' && searchTerm.trim()) {
      const numericCode = searchTerm.replace(/[^0-9]/g, '');
      if (numericCode.length === 0) {
        toast.error("Veuillez entrer un code-barres valide (chiffres uniquement).");
        return;
      }
      const produit = produitsDisponibles.find((p) => p.id.toString() === numericCode);
      if (produit && produit.quantite > 0) {
        handleAddToCart(produit);
        toast.success(`${produit.nom} ajouté au panier !`);
        setSearchTerm('');
      } else {
        toast.error("Produit non trouvé ou en rupture de stock.");
      }
    }
  };

  return (
    <div style={{ display: "flex", height: "calc(100vh - 80px)", backgroundColor: "#f4f6f9", userSelect: "none" }}>
      <input
        type="text"
        ref={barcodeInputRef}
        value={barcode}
        onChange={(e) => setBarcode(e.target.value)}
        style={{ 
          position: "absolute", 
          left: "-9999px",
          opacity: 0,
          width: "1px",
          height: "1px"
        }}
        aria-hidden="true"
      />

      <div style={{ flex: 1, padding: "20px", overflowY: "auto" }}>
        <div style={{ marginBottom: "20px", display: "flex", gap: "15px" }} className="w-[100%]">
          <input
            type="text"
            ref={searchInputRef}
            value={searchTerm}
            onChange={handleSearchChange}
            onKeyPress={handleSearchKeyPress}
            placeholder="Rechercher ou scanner un produit (chiffres uniquement)"
            className="w-[60%]"
            style={{
              flex: 1,
              padding: "12px",
              borderRadius: "8px",
              border: "1px solid #d1d5db",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            }}
          />
          <select
            value={selectedCategory}
            className="w-[30%]"
            onChange={(e) => setSelectedCategory(e.target.value)}
            style={{
              padding: "12px",
              borderRadius: "8px",
              border: "1px solid #d1d5db",
              backgroundColor: "#fff",
              boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
            }}
          >
            <option value="">Toutes les catégories</option>
            {categories.map((item) => (
              <option key={item.id} value={item.id}>
                {item.nom}
              </option>
            ))}
          </select>
        </div>
        
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "20px" }}>
          {filteredProduits.map((prod) => (
            <div
              key={prod.id}
              className="flex flex-col justify-between"
              onClick={() => handleAddToCart(prod)}
              style={{
                padding: "20px",
                backgroundColor: "#fff",
                borderRadius: "12px",
                border: "1px solid #e5e7eb",
                boxShadow: "0 6px 12px rgba(0, 0, 0, 0.06)",
                cursor: prod.quantite > 0 ? "pointer" : "not-allowed",
                transition: "transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out",
                minHeight: "300px",
              }}
              onMouseEnter={(e) => prod.quantite > 0 && (e.currentTarget.style.transform = "scale(1.03)") && (e.currentTarget.style.boxShadow = "0 8px 16px rgba(0, 0, 0, 0.1)")}
              onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)") && (e.currentTarget.style.boxShadow = "0 6px 12px rgba(0, 0, 0, 0.06)")}
            >
              <div className="w-full flex justify-center">
                <img
                  src={getProductImage(prod)}
                  alt={prod.nom}
                  className="w-[60%] object-cover rounded-lg"
                  style={{ maxWidth: "100%", border: "1px solid #f1f5f9" }}
                />
              </div>
              <h3
                style={{
                  textAlign: "center",
                  margin: "15px 0 10px",
                  fontSize: "1.2rem",
                  fontWeight: "600",
                  color: "#1f2937",
                  lineHeight: "1.4",
                }}
              >
                {prod.nom}
              </h3>
              <div className="flex flex-col items-center gap-2">
                <p
                  style={{
                    textAlign: "center",
                    color: "#4b5563",
                    fontSize: "1rem",
                    fontWeight: "500",
                  }}
                >
                  Prix : <span style={{ color: "#1e40af", fontWeight: "600" }}>{prod.prix_vente} DA</span>
                </p>
                <p
                  style={{
                    textAlign: "center",
                    color: prod.quantite > 0 ? "#059669" : "#dc2626",
                    fontSize: "0.95rem",
                    fontWeight: "500",
                    padding: "4px 8px",
                    backgroundColor: prod.quantite > 0 ? "#ecfdf5" : "#fee2e2",
                    borderRadius: "4px",
                  }}
                >
                  Stock : {prod.quantite}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div
        style={{
          width: "35%",
          backgroundColor: "#fff",
          padding: "20px",
          display: "flex",
          flexDirection: "column",
          borderLeft: "1px solid #e5e7eb",
          boxShadow: "0 4px 6px rgba(0,0,0,0.05)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "#1e3a8a",
            borderRadius: "10px",
            padding: "15px",
            marginBottom: "20px",
            color: "#fff",
            fontFamily: "'Roboto', sans-serif",
            fontSize: "1.8rem",
            fontWeight: "bold",
          }}
        >
          {totalPrix.toFixed(2)} DA
        </div>

        <div className="flex-1 overflow-y-auto mb-6">
          {achat.produits.length === 0 ? (
            <p className="text-center text-gray-500 text-base font-medium py-8">
              Aucun produit ajouté.
            </p>
          ) : (
            <ul className="list-none p-0 space-y-4">
              {achat.produits.map((produit) => {
                const produitDetails = produitsDisponibles.find((p) => p.id === produit.produit_id);
                return (
                  <li
                    key={produit.produit_id}
                    className="bg-white p-2 rounded-lg flex flex-col justify-between shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200"
                  >
                    <div className="flex items-center justify-between px-2">
                      <div className="flex">
                        <div className="w-[60px]">
                          <img
                            src={getProductImage(produitDetails)}
                            alt={produitDetails?.nom}
                            className="min-w-[70%] h-[50px] rounded-md object-cover mr-4"
                          />
                        </div>
                        <div className="flex flex-col">
                          <h4 className="m-0 text-base font-semibold text-gray-800">
                            {truncateText(produitDetails?.nom || "", 8)}
                          </h4>
                          <p className="mt-1 text-sm text-gray-600">
                            Quantité : {produit.quantite}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={produit.prix}
                          onChange={(e) => handlePriceChange(produit.produit_id, e.target.value)}
                          className="w-24 p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all duration-200"
                        />
                        <button
                          onClick={() => handleOpenWarrantyModal(produit.produit_id)}
                          className="bg-green-500 text-white p-1 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-yellow-500/50 transition-colors duration-200 text-sm font-medium"
                        >
                          Garantie
                        </button>
                        <button
                          onClick={() => handleRemoveProduit(produit.produit_id)}
                          className="bg-red-500 text-white p-1 rounded-[40%] hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500/50 transition-colors duration-200 text-sm font-medium"
                        >
                          <svg
                            className="w-4 h-4"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                            xmlns="http://www.w3.org/2000/svg"
                          >
                            <path
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth={2}
                              d="M3 6h18M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2M5 6h14l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6z"
                            />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "15px" }}>
            <button
              type="button"
              className={`bg-[#ffffff] border-[2px] rounded-lg ${
                !achat.client.nomComplet ? 'text-[#bcb7b7ce] border-[#bcb7b7ce]' : "text-[#16933f] border-[#16934090]"
              }`}
              onClick={handleOpenClientModal}
              style={{
                width: "100%",
                padding: "12px",
                cursor: "pointer",
                fontSize: "1rem",
                fontWeight: "500",
                transition: "background-color 0.2s",
              }}
            >
              {achat.client.nomComplet ? `Client: ${achat.client.nomComplet}` : "Sélectionner un client"}
            </button>
          </div>
          <button
            type="submit"
            style={{
              width: "100%",
              padding: "12px",
              backgroundColor: "#1e3a8a",
              color: "#fff",
              borderRadius: "8px",
              border: "none",
              cursor: "pointer",
              fontSize: "1rem",
              fontWeight: "500",
              transition: "background-color 0.2s",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#1e40af")}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#1e3a8a")}
          >
            Enregistrer l'achat
          </button>
        </form>

        {isClientModalOpen && (
          <div
            className="fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full h-screen bg-black bg-opacity-50"
            onClick={handleCloseClientModal}
          >
            <div
              className="relative p-4 w-full max-w-md bg-white rounded-lg shadow"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b rounded-t">
                <h3 className="text-lg font-semibold text-gray-900">
                  Informations du client
                </h3>
                <button
                  type="button"
                  className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 inline-flex justify-center items-center"
                  onClick={handleCloseClientModal}
                >
                  <svg
                    className="w-3 h-3"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    />
                  </svg>
                  <span className="sr-only">Fermer</span>
                </button>
              </div>

              <div className="p-4">
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Nom complet
                  </label>
                  <input
                    type="text"
                    name="nomComplet"
                    value={achat.client.nomComplet}
                    onChange={handleClientChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  />
                </div>
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Numéro de téléphone
                  </label>
                  <input
                    type="text"
                    name="telephone"
                    value={achat.client.telephone}
                    onChange={handleClientChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  />
                </div>
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={achat.client.email}
                    onChange={handleClientChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  />
                </div>
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Wilaya
                  </label>
                  <select
                    name="wilaya"
                    value={achat.client.wilaya}
                    onChange={handleClientChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  >
                    <option value="">Sélectionner une wilaya</option>
                    {wilayas.map((wilaya, index) => (
                      <option key={index} value={wilaya}>
                        {wilaya}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Recommandation
                  </label>
                  <select
                    name="recommandation"
                    value={achat.client.recommandation}
                    onChange={handleClientChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  >
                    <option value="">Sélectionner une source</option>
                    {recommandations.map((recommandation, index) => (
                      <option key={index} value={recommandation}>
                        {recommandation}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  type="button"
                  onClick={handleSaveClient}
                  className="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                >
                  Enregistrer
                </button>
              </div>
            </div>
          </div>
        )}

        {isWarrantyModalOpen && (
          <div
            className="fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full h-screen bg-black bg-opacity-50"
            onClick={handleCloseWarrantyModal}
          >
            <div
              className="relative p-4 w-full max-w-sm bg-white rounded-lg shadow"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b rounded-t">
                <h3 className="text-lg font-semibold text-gray-900">
                  Garantie
                </h3>
                <button
                  type="button"
                  className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 inline-flex justify-center items-center"
                  onClick={handleCloseWarrantyModal}
                >
                  <svg
                    className="w-3 h-3"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 14 14"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                    />
                  </svg>
                  <span className="sr-only">Fermer</span>
                </button>
              </div>

              <div className="p-4">
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Numéro de garantie
                  </label>
                  <input
                    type="text"
                    name="code_garantie"
                    value={warrantyData.code_garantie}
                    onChange={handleWarrantyChange}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2.5"
                  />
                </div>
                <div className="mb-4">
                  <label className="block mb-2 text-sm font-medium text-gray-900">
                    Durée de garantie
                  </label>
                  <div className="flex flex-col gap-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        name="duree_garantie"
                        value="1 mois"
                        checked={warrantyData.duree_garantie === "1 mois"}
                        onChange={handleWarrantyChange}
                        className="mr-2"
                      />
                      1 mois
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        name="duree_garantie"
                        value="3 mois"
                        checked={warrantyData.duree_garantie === "3 mois"}
                        onChange={handleWarrantyChange}
                        className="mr-2"
                      />
                      3 mois
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        name="duree_garantie"
                        value="6 mois"
                        checked={warrantyData.duree_garantie === "6 mois"}
                        onChange={handleWarrantyChange}
                        className="mr-2"
                      />
                      6 mois
                    </label>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleSaveWarranty}
                  className="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center"
                >
                  Enregistrer
                </button>
              </div>
            </div>
          </div>
        )}

{isSaleModalOpen && (
        <div
          className="fixed top-0 right-0 left-0 z-50 flex justify-center items-center w-full h-screen bg-black bg-opacity-50"
          onClick={handleCloseSaleModal}
        >
          <div
            className="relative p-4 w-full max-w-md bg-white rounded-lg shadow"
            style={{ maxHeight: "90vh", display: "flex", flexDirection: "column" }} // Limite la hauteur et structure en colonne
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 border-b rounded-t">
              <h3 className="text-lg font-semibold text-gray-900">
                Détails de la vente
              </h3>
              <button
                type="button"
                className="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 inline-flex justify-center items-center"
                onClick={handleCloseSaleModal}
              >
                <svg
                  className="w-3 h-3"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 14 14"
                >
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                  />
                </svg>
                <span className="sr-only">Fermer</span>
              </button>
            </div>

            <div className="p-4 overflow-y-auto" style={{ flex: 1 }}> {/* Contenu scrollable */}
              <div className="mb-3">
                <label className="block mb-1 text-sm font-medium text-gray-900">
                  Objet de vente
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="saleType"
                      value="comptoir"
                      checked={saleData.saleType === "comptoir"}
                      onChange={handleSaleChange}
                      className="mr-2"
                    />
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                    </svg>
                    Comptoir
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="saleType"
                      value="livraison"
                      checked={saleData.saleType === "livraison"}
                      onChange={handleSaleChange}
                      className="mr-2"
                    />
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                    </svg>
                    Livraison
                  </label>
                </div>
              </div>

              {saleData.saleType === "livraison" && (
                <>
                  <div className="mb-3">
                    <label className="block mb-1 text-sm font-medium text-gray-900">
                      Fournisseur de livraison
                    </label>
                    <select
                      name="deliveryProvider"
                      value={saleData.deliveryProvider}
                      onChange={handleSaleChange}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
                    >
                      <option value="yalidine">Yalidine</option>
                      <option value="autre">Autre</option>
                    </select>
                  </div>
                  <div className="mb-3">
                    <label className="block mb-1 text-sm font-medium text-gray-900">
                      Prix de livraison (DA)
                    </label>
                    <input
                      type="text"
                      name="deliveryPrice"
                      value={saleData.deliveryPrice}
                      onChange={handleSaleChange}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
                      placeholder="Entrez le prix"
                    />
                  </div>
                </>
              )}

              <div className="mb-3">
                <label className="block mb-1 text-sm font-medium text-gray-900">
                  Mode de vente
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="saleMode"
                      value="direct"
                      checked={saleData.saleMode === "direct"}
                      onChange={handleSaleChange}
                      className="mr-2"
                    />
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Direct
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="saleMode"
                      value="versement"
                      checked={saleData.saleMode === "versement"}
                      onChange={handleSaleChange}
                      className="mr-2"
                    />
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6h4m-4-6V4m0 8v2m6-6h-2m-4 0H6m12 6h-2m-4 0H6" />
                    </svg>
                    Versement
                  </label>
                </div>
              </div>

              <div className="mb-3">
                <label className="block mb-1 text-sm font-medium text-gray-900">
                  Modes de paiement (Total à payer : {(totalPrix + (saleData.saleType === "livraison" ? parseFloat(saleData.deliveryPrice) || 0 : 0)).toFixed(2)} DA)
                </label>
                <div className="flex flex-col gap-3">
                  {paymentOptions.map((option) => {
                    const isChecked = saleData.paymentMethods.some((pm) => pm.method === option.value);
                    const payment = saleData.paymentMethods.find((pm) => pm.method === option.value) || { installments: [{ amount: "", date: "" }] };
                    return (
                      <div key={option.value} className="flex flex-col">
                        <label className="flex items-center mb-1">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => handlePaymentChange(option.value, e.target.checked)}
                            className="mr-2"
                          />
                          {option.icon}
                          {option.label}
                        </label>
                        {isChecked && (
                          <div className="ml-6">
                            {payment.installments.map((inst, index) => (
                              <div key={index} className="flex flex-col gap-2 mb-2">
                                <input
                                  type="text"
                                  value={inst.amount}
                                  onChange={(e) =>
                                    handlePaymentInstallmentChange(option.value, index, "amount", e.target.value)
                                  }
                                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
                                  placeholder={`Montant en DA`}
                                />
                                {saleData.saleMode === "versement" && (
                                  <>
                                    <input
                                      type="date"
                                      value={inst.date}
                                      onChange={(e) =>
                                        handlePaymentInstallmentChange(option.value, index, "date", e.target.value)
                                      }
                                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
                                    />
                                    {index > 0 && (
                                      <button
                                        type="button"
                                        onClick={() => removeInstallment(option.value, index)}
                                        className="text-red-500 hover:text-red-700 text-xs"
                                      >
                                        Supprimer ce versement
                                      </button>
                                    )}
                                  </>
                                )}
                              </div>
                            ))}
                            {saleData.saleMode === "versement" && (
                              <button
                                type="button"
                                onClick={() => addInstallment(option.value)}
                                className="text-blue-500 hover:text-blue-700 text-xs"
                              >
                                + Ajouter un versement
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="mb-3">
                <label className="block mb-1 text-sm font-medium text-gray-900">
                  Commentaire
                </label>
                <textarea
                  name="comment"
                  value={saleData.comment}
                  onChange={handleSaleChange}
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg block w-full p-2"
                  rows="3"
                  placeholder="Ajoutez un commentaire..."
                />
              </div>
            </div>

            <div className="p-4 border-t">
              <button
                type="button"
                onClick={handleConfirmSale}
                className="w-full text-white bg-blue-600 hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2 text-center"
              >
                Confirmer la vente
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};

export default AjouterFacture;