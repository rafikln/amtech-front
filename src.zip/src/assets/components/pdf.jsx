import React from "react";
import { Page, Text, View, Document, StyleSheet, Font, Image } from "@react-pdf/renderer";
import JsBarcode from "jsbarcode";
import { createCanvas } from "canvas";

// Importer le logo
import logo from "/amtech.png"; // Chemin adapté pour Vite (public/amtech.png)
import factur from "/facture.png"
// Register Helvetica font for a professional look
Font.register({
  family: "Helvetica",
  fonts: [
    { src: "https://fonts.gstatic.com/s/helvetica/v15/Helvetica.ttf" },
    { src: "https://fonts.gstatic.com/s/helvetica/v15/Helvetica-Bold.ttf", fontWeight: "bold" },
  ],
});

// Styles pour un design professionnel
const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontFamily: "Helvetica",
    fontSize: 10,
    color: "#333",
    backgroundColor: "#fff",
  },
  header: {
    textAlign: "center",
    marginBottom: 5,
    borderBottomWidth: 1,
    borderBottomColor: "#1A3C5A",
    paddingBottom: 10,
  },
  headers: {
    textAlign: "center",
    marginBottom: 10,

  },
  logo: {
    width: 200, // Largeur du logo
    height: 50, // Hauteur du logo
    marginBottom: 10, // Espace sous le logo
    alignSelf: "center", // Centre le logo horizontalement dans son conteneur
  },
  logoo: {
    width: 200, // Largeur du logo
    alignSelf: "center", // Centre le logo horizontalement dans son conteneur
  },
  subHeader: {
    fontSize: 12,
    marginTop: 5,
    color: "#555",
  },
  contactInfo: {
    fontSize: 10,
    marginTop: 5,
    color: "#777",
  },
  infoSection: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
    padding: 10,
    backgroundColor: "#F9F9F9",
    borderWidth: 1,
    borderColor: "#E0E0E0",
    borderRadius: 5,
  },
  clientInfo: {
  },
  invoiceInfo: {
    textAlign: "left",
  },
  barcodeSection: {
    textAlign: "center",
  },
  barcodeImage: {
    width: 150, // Largeur du code-barres
    height: 60, // Hauteur du code-barres
    alignSelf: "center", // Centre l'image du code-barres
  },
  table: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#E0E0E0",
    borderRadius: 5,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#1A3C5A",
    color: "#fff",
    padding: 8,
    fontWeight: "bold",
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
  },
  tableRow: {
    flexDirection: "row",
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  tableRowEven: {
    backgroundColor: "#F5F5F5",
  },
  tableCell: {
    flex: 1,
    textAlign: "center",
  },
  totalsContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 20,
  },
  totalsTable: {
    width: "40%",
    borderWidth: 1,
    borderColor: "#E0E0E0",
    borderRadius: 5,
  },
  totalsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 8,
    borderBottomWidth: 1,
    borderBottomColor: "#E0E0E0",
  },
  totalsRowLast: {
    borderBottomWidth: 0,
  },
  footer: {
    position: "absolute",
    bottom: 30,
    left: 30,
    right: 30,
    borderTopWidth: 1,
    borderTopColor: "#1A3C5A",
    paddingTop: 10,
    fontSize: 9,
    color: "#555",
    textAlign: "center",
  },
  textBold: {
    fontWeight: "bold",
  },
  textRight: {
    textAlign: "right",
  },
});

// Fonction pour générer une image de code-barres
const generateBarcodeImage = (id) => {
  const canvas = createCanvas(200, 100); // Dimensions du canvas
  JsBarcode(canvas, id.toString().padStart(12, "0"), {
    format: "CODE128",
    width: 2,
    height: 50,
    displayValue: false, // Affiche le numéro sous le code-barres
  });
  return canvas.toDataURL("image/png"); // Retourne une URL base64
};

// Composant FacturePDF
const FacturePDF = ({ facture = {} }) => {
  const {
    id = "N/A",
    nom_client = "Non spécifié",
    date_creation = new Date().toISOString(),
    prix_total = "0.00",
    produits = [],
  } = facture;

  // Calcul du total des produits pour vérification
  const calculatedTotal = produits
    .reduce((sum, produit) => sum + parseFloat(produit.prix_total || 0), 0)
    .toFixed(2);

  // Formatage de la date
  const formattedDate = new Date(date_creation).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Générer l'image du code-barres
  const barcodeImageUrl = generateBarcodeImage(id);

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* En-tête avec logo centré */}
        <View style={styles.header}>
          <Image src={logo} style={styles.logo} />
          <Text style={styles.subHeader}>
            Magasin de Vente Matériel Informatique : Laptop / Smartphone / Accessoires
          </Text>
          <Text style={styles.contactInfo}>
            Adresse: 15 Rue Bois des Cars 1, Dely Ibrahim, Code Postal: 16302, Alger
          </Text>
          <Text style={styles.contactInfo}>Tél: 0792 294 989 / 0556 294 989</Text>
        </View>

        <View style={styles.headers}>
          <Image src={factur} style={styles.logoo} /> {/* Vérifiez cette image */}
        </View>
        {/* Informations client et facture */}
        <View style={styles.infoSection}>
          <View style={styles.clientInfo}>
            <Text style={styles.textBold}>Client: {nom_client}</Text>
            <Text>Adresse: [Non spécifiée]</Text>
            <Text>Tél: [Non spécifié]</Text>
          </View>

          <View style={styles.barcodeSection}>
          <Image src={barcodeImageUrl} style={styles.barcodeImage} />
        </View>

          <View style={styles.invoiceInfo}>
            <Text style={styles.textBold}>Facture #{id}</Text>
            <Text>Date: {formattedDate}</Text>
            <Text>Objet: Vente Comptoir / Livraison</Text>
          </View>
        </View>

      

        {/* Tableau des produits (sans Code Garantie) */}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={[styles.tableCell, { flex: 0.5 }]}>N°</Text>
            <Text style={[styles.tableCell, { flex: 2 }]}>Désignation</Text>
            <Text style={styles.tableCell}>Quantité</Text>
            <Text style={styles.tableCell}>Prix Unitaire</Text>
            <Text style={styles.tableCell}>Total</Text>
            <Text style={styles.tableCell}>Durée Garantie</Text>
          </View>
          {produits.length > 0 ? (
            produits.map((produit, index) => (
              <View
                key={index}
                style={[styles.tableRow, index % 2 === 0 ? styles.tableRowEven : {}]}
              >
                <Text style={[styles.tableCell, { flex: 0.5 }]}>{index + 1}</Text>
                <Text style={[styles.tableCell, { flex: 2 }]}>{produit.nom || "Non spécifié"}</Text>
                <Text style={styles.tableCell}>{produit.quantite || 0}</Text>
                <Text style={styles.tableCell}>
                  {parseFloat(produit.prix_vente || 0).toFixed(2)} DA
                </Text>
                <Text style={styles.tableCell}>
                  {parseFloat(produit.prix_total || 0).toFixed(2)} DA
                </Text>
                <Text style={styles.tableCell}>{produit.duree_garantie || "-"}</Text>
              </View>
            ))
          ) : (
            <View style={styles.tableRow}>
              <Text style={[styles.tableCell, { flex: 0.5 }]}>1</Text>
              <Text style={[styles.tableCell, { flex: 2 }]}>Aucun produit</Text>
              <Text style={styles.tableCell}>0</Text>
              <Text style={styles.tableCell}>0.00 DA</Text>
              <Text style={styles.tableCell}>0.00 DA</Text>
              <Text style={styles.tableCell}>-</Text>
            </View>
          )}
          {produits.length > 0 && (
            <View style={[styles.tableRow, { borderBottomWidth: 0 }]}>
              <Text style={[styles.tableCell, { flex: 0.5 }]}></Text>
              <Text style={[styles.tableCell, { flex: 2, textAlign: "right" }]}>
                Total Calculé:
              </Text>
              <Text style={styles.tableCell}></Text>
              <Text style={styles.tableCell}></Text>
              <Text style={styles.tableCell}>{calculatedTotal} DA</Text>
              <Text style={styles.tableCell}></Text>
            </View>
          )}
        </View>

        {/* Totaux */}
        <View style={styles.totalsContainer}>
          <View style={styles.totalsTable}>
            <View style={styles.totalsRow}>
              <Text style={styles.textBold}>Total HT:</Text>
              <Text style={styles.textRight}>{calculatedTotal} DA</Text>
            </View>
            <View style={[styles.totalsRow, styles.totalsRowLast]}>
              <Text style={styles.textBold}>Total TTC (Facture):</Text>
              <Text style={styles.textRight}>{parseFloat(prix_total).toFixed(2)} DA</Text>
            </View>
          </View>
        </View>

        {/* Note sur la différence si applicable */}
        {parseFloat(prix_total) !== parseFloat(calculatedTotal) && (
          <Text style={{ color: "#D32F2F", fontSize: 9, textAlign: "right", marginTop: 5 }}>
            Note: Le total de la facture diffère du total calculé des produits.
          </Text>
        )}

        {/* Pied de page */}
        <View style={styles.footer} fixed>
          <Text>NOUS VOUS REMERCIONS DE VOTRE CONFIANCE</Text>
          <Text>AMTECH DELY IBRAHIM - Tous droits réservés</Text>
        </View>
      </Page>
    </Document>
  );
};

export default FacturePDF;