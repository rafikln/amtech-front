import jsPDF from 'jspdf';
import 'jspdf-autotable';
import Barcode from 'react-barcode';

// ... autres imports

const generateProductTicket = (produit) => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: [80, 80] // Format de ticket (80x80mm)
  });

  // Titre
  doc.setFontSize(12);
  doc.text(`Ticket Produit`, 40, 10, { align: 'center' });

  // Code-barres
  const barcodeSvg = document.createElement('svg');
  const barcode = (
    <Barcode 
      value={produit.id.toString()} 
      width={1.5}
      height={30}
      fontSize={10}
      displayValue={true}
    />
  );
  ReactDOM.render(barcode, barcodeSvg);
  const svgData = new XMLSerializer().serializeToString(barcodeSvg);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const img = new Image();
  
  img.onload = () => {
    ctx.drawImage(img, 0, 0);
    const pngData = canvas.toDataURL('image/png');
    doc.addImage(pngData, 'PNG', 20, 15, 40, 20);
    
    // Informations du produit
    doc.setFontSize(10);
    doc.text(`Nom: ${produit.nom}`, 10, 40);
    doc.text(`Réf: ${produit.reference || '-'}`, 10, 45);
    doc.text(`Prix: ${produit.prix_vente} DA`, 10, 50);
    doc.text(`Qte: ${produit.quantite}`, 10, 55);
    
    // Sauvegarde du PDF
    doc.save(`ticket_${produit.reference || produit.id}.pdf`);
  };
  
  img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
};