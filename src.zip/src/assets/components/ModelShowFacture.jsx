import { useState } from "react";
import Barcode from "react-barcode";
import { ClipboardIcon } from "@heroicons/react/24/outline";

const ModelShowFacture = ({ isModalOpen, selectedFacture, handleCloseModal }) => {
  const [copied, setCopied] = useState(false);

  if (!selectedFacture) return null;

  // Calcul du total des produits pour vérification
  const calculatedTotal = selectedFacture.produits
    ? selectedFacture.produits.reduce((sum, produit) => sum + parseFloat(produit.prix_total || 0), 0)
    : 0;

  const isTotalMismatch = parseFloat(selectedFacture.prix_total) !== calculatedTotal;

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatDate = (isoDate) => {
    return new Date(isoDate).toLocaleDateString("fr-FR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Composant pour formater les prix avec "DA" à côté
  const PriceDisplay = ({ value }) => (
    <span className="text-gray-700 dark:text-gray-300">
      {parseFloat(value || 0).toFixed(2)} DA
    </span>
  );

  return (
    <>
      {isModalOpen && (
        <div
          id="crud-modal"
          className="fixed inset-0 z-50 flex justify-center items-center w-full h-screen bg-[#00000058] bg-opacity-60"
          onClick={handleCloseModal}
        >
          <div
            className="relative p-6 w-full max-w-6xl max-h-[90vh] overflow-y-auto bg-white rounded-xl shadow-xl dark:bg-gray-800"
            onClick={(e) => e.stopPropagation()}
          >
            {/* HEADER */}
            <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-700">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                Facture #{selectedFacture.id} - {selectedFacture.nom_client}
              </h3>
              <button
                type="button"
                className="text-gray-400 hover:bg-gray-200 hover:text-gray-900 rounded-lg p-1.5 dark:hover:bg-gray-600 dark:hover:text-white"
                onClick={handleCloseModal}
              >
                <svg className="w-4 h-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                  <path
                    stroke="currentColor"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                  />
                </svg>
              </button>
            </div>

            <div className="mt-6 space-y-6">
              {/* Informations générales */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Numéro de facture</p>
                  <div className="flex items-center space-x-2">
                    <Barcode
                      value={selectedFacture.id.toString()}
                      width={1.5}
                      height={40}
                      fontSize={14}
                      margin={10}
                      displayValue={true}
                    />
                    <button
                      onClick={() => handleCopy(selectedFacture.id.toString())}
                      className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                      title="Copier l'ID"
                    >
                      <ClipboardIcon className="w-5 h-5" />
                    </button>
                    {copied && <span className="text-xs text-green-500">Copié !</span>}
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Nom du client</p>
                  <p className="text-lg text-gray-900 dark:text-white">{selectedFacture.nom_client}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Date de création</p>
                  <p className="text-lg text-gray-900 dark:text-white">{formatDate(selectedFacture.date_creation)}</p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Prix total</p>
                  <p
                    className={`text-lg font-semibold ${
                      isTotalMismatch ? "text-red-600 dark:text-red-400" : "text-gray-900 dark:text-white"
                    }`}
                  >
                    <PriceDisplay value={selectedFacture.prix_total} />
                    {isTotalMismatch && (
                      <span className="text-xs ml-2">(Diffère du total calculé)</span>
                    )}
                  </p>
                </div>
              </div>

              {/* Liste des produits */}
              <div>
                <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Détails des produits</h4>
                <div className="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
                  <table className="w-full text-sm text-left text-gray-700 dark:text-gray-300">
                    <thead className="bg-gray-100 dark:bg-gray-700">
                      <tr>
                        <th className="px-4 py-3 font-medium">ID Produit</th>
                        <th className="px-4 py-3 font-medium">Nom</th>
                        <th className="px-4 py-3 font-medium">Quantité</th>
                        <th className="px-4 py-3 font-medium">Prix Vente</th>
                        <th className="px-4 py-3 font-medium">Prix Total</th>
                        <th className="px-4 py-3 font-medium">Code Garantie</th>
                        <th className="px-4 py-3 font-medium">Durée Garantie</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedFacture.produits && selectedFacture.produits.length > 0 ? (
                        selectedFacture.produits.map((produit, index) => (
                          <tr key={index} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                            <td className="px-4 py-3">{produit.id}</td>
                            <td className="px-4 py-3">{produit.nom}</td>
                            <td className="px-4 py-3">{produit.quantite}</td>
                            <td className="px-4 py-3">
                              <PriceDisplay value={produit.prix_vente} />
                            </td>
                            <td className="px-4 py-3">
                              <PriceDisplay value={produit.prix_total} />
                            </td>
                            <td className="px-4 py-3  text-center">{produit.code_garantie || "-"}</td>
                            <td className="px-4 py-3  text-center">
                              {produit.duree_garantie ? `${produit.duree_garantie} mois` : "-"}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="7" className="px-4 py-3 text-center text-gray-500 dark:text-gray-400">
                            Aucun produit trouvé
                          </td>
                        </tr>
                      )}
                    </tbody>
                    {selectedFacture.produits && selectedFacture.produits.length > 0 && (
                      <tfoot>
                        <tr className="font-semibold bg-gray-50 dark:bg-gray-700">
                          <td colSpan="4" className="px-4 py-3 text-right">Total calculé :</td>
                          <td className="px-4 py-3">
                            <PriceDisplay value={calculatedTotal} />
                          </td>
                          <td colSpan="2" className="px-4 py-3"></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ModelShowFacture;